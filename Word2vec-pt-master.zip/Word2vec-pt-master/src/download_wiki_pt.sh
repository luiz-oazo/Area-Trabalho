wget https://www.dropbox.com/s/6dw2255xieavz42/text8.zip?dl=0
wget https://www.dropbox.com/s/b771vr92wogo0dn/pt96.zip?dl=0
unzip pt96.zip?dl=0
unzip text8.zip?dl=0
mkdir corpora
mv pt96.txt corpora/pt96.txt
mv text8 corpora/text8.txt

rm pt96.zip?dl=0
rm text8.zip?dl=0


